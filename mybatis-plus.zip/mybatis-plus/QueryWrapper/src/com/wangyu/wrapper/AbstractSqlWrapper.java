package com.wangyu.wrapper;

import com.wangyu.support.SFunction;

/**
 * Created by wangyu
 * Date: 2019/9/5
 * Time: 10:41 AM
 * Description:
 */
public class AbstractSqlWrapper<T,Children extends AbstractSqlWrapper<T,Children>>
    implements SqlCompare<Children,SFunction<T,?>> {
}
