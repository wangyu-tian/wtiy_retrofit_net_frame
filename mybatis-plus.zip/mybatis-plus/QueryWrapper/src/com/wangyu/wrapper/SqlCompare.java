package com.wangyu.wrapper;

public interface SqlCompare<Children, T> {
}
