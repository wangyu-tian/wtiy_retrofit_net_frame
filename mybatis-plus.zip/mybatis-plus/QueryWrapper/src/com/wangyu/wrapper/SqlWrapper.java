package com.wangyu.wrapper;

import java.sql.SQLWarning;

/**
 * Created by wangyu
 * Date: 2019/9/5
 * Time: 10:41 AM
 * Description:
 */
public class SqlWrapper<T> extends AbstractSqlWrapper<T,SqlWrapper<T>>{
}
