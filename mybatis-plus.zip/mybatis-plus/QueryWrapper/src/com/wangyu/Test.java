package com.wangyu;

/**
 * Created by wangyu
 * Date: 2019/9/5
 * Time: 10:39 AM
 * Description:
 */
public class Test {
    public static void main(String[] args){

        System.out.println("测试");
    }
}
