delete from h2student;
insert into h2student (id, name, age)values (1, 'Tom', 1);
insert into h2student (id, name, age)values (2, 'Jerry', 1);
insert into h2student (id, name, age)values (12, '要开除的学生', 1);
insert into h2student (id, name, age)values (13, 'test1', 1);
insert into h2student (id, name, age)values (14, 'test2', 1);
insert into h2student (id, name, age)values (15, 'test3', 1);
