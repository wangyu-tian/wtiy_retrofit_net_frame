delete from h2user;
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (101, 'Tomcat', '2017-1-1 1:1:1', 3, 9.99, 1, 1, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (102, 'Jerry', '2017-3-1 1:1:1', 2, 19.99, 2, 2, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (103, 'Bob', '2017-4-1 1:1:1', 1, 99.99, 3, 3, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (104, 'Joe', '2017-2-1 1:1:1', 1, 1.99, 1, 4, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (105, 'Tony', '2017-2-1 1:1:1', 3, 1.99, 1, 5, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (1010, '1010', '2017-2-1 1:1:1', 3, 1.99, 1, 5, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (1011, '1011', '2017-2-1 1:1:1', 3, 1.99, 1, 5, 0);
insert into h2user (test_id, name, test_date, age, price, test_type, version, deleted)values (1012, '1012', '2017-2-1 1:1:1', 3, 1.99, 1, 5, 0);
