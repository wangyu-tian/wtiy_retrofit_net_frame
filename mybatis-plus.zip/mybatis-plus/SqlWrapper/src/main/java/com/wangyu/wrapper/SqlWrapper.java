package com.wangyu.wrapper;

import com.wangyu.model.LambdaSqlModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wangyu
 * Date: 2019/9/5
 * Time: 10:41 AM
 * Description:
 */
public class SqlWrapper<T> extends AbstractSqlWrapper<T,SqlWrapper<T>>{

    public SqlWrapper(Class<T> entityClass){
        super(entityClass);
    }
}
