package com.wangyu;

import com.wangyu.support.WrapperConstant;
import com.wangyu.wrapper.AbstractSqlWrapper;
import com.wangyu.wrapper.SqlWrapper;

import static java.util.Arrays.asList;

/**
 * Created by wangyu
 * Date: 2019/9/5
 * Time: 10:39 AM
 * Description:
 */
public class Test {
    public static void main(String[] args){

        SqlWrapper<EntityModel> sqlWrapper = new SqlWrapper<>(EntityModel.class);
        sqlWrapper.eq(EntityModel::getId,12)
            .le(EntityModel::getName,"zhangsan")
            .lt(EntityModel::getSex,"88",true)
            .or()
            .in(EntityModel::getId,asList("12","23","444"))
            .like(EntityModel::getId,"123",true,WrapperConstant.LIKE_RIGHT)
        .notIn(EntityModel::getName,asList(12,33,24))
        .eq(EntityModel::getId,"123")
        .and(wrapper->wrapper.ge(EntityModel::getName,"169219").eq(EntityModel::getId,12))
        .or(wrapper->wrapper.le(EntityModel::getName,"name").eq(EntityModel::getId,88));
        ;
        System.out.println(sqlWrapper.getHql());
    }
}
