package com.wangyu.support;

/**
 * Created by wangyu
 * Date: 2019/9/6
 * Time: 9:36 AM
 * Description:
 */
public class WrapperConstant {
    public static final int LIKE_LEFT = 1;
    public static final int LIKE_RIGHT = 2;
    public static final int LIKE_ALL = 3;
}
